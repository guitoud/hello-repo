-- MySQL dump 10.11
--
-- Host: localhost    Database: portail_ope_dev 
-- ------------------------------------------------------
-- Server version	5.0.51a-3ubuntu5.7

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `portail_ope_dev`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `portail_ope_dev` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `portail_ope_dev`;

--
-- Table structure for table `moteur_droit`
--

DROP TABLE IF EXISTS `moteur_droit`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `moteur_droit` (
  `DROIT_ID` int(20) NOT NULL auto_increment,
  `ROLE_ID` int(20) NOT NULL,
  `PAGES_ID` int(20) NOT NULL,
  `DROIT` varchar(2) NOT NULL,
  PRIMARY KEY  (`DROIT_ID`),
  KEY `ROLE_ID` (`ROLE_ID`),
  KEY `PAGES_ID` (`PAGES_ID`),
  KEY `PAGES_ID_2` (`PAGES_ID`),
  KEY `ROLE_ID_2` (`ROLE_ID`)
) ENGINE=MyISAM AUTO_INCREMENT=32 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `moteur_droit`
--

LOCK TABLES `moteur_droit` WRITE;
/*!40000 ALTER TABLE `moteur_droit` DISABLE KEYS */;
INSERT INTO `moteur_droit` (`DROIT_ID`, `ROLE_ID`, `PAGES_ID`, `DROIT`) VALUES (1,1,1,'OK'),(2,1,2,'OK'),(3,1,3,'OK'),(4,1,4,'OK'),(5,1,5,'OK'),(6,1,6,'OK'),(7,1,7,'OK'),(8,1,8,'OK'),(9,1,9,'OK'),(10,1,10,'OK'),(11,1,11,'OK'),(12,1,12,'OK'),(13,1,13,'OK'),(14,2,1,'OK'),(15,2,2,'OK'),(16,1,14,'OK'),(17,1,15,'OK'),(18,1,16,'OK'),(19,1,17,'OK'),(23,1,18,'OK'),(24,1,19,'OK'),(25,1,20,'OK'),(26,1,21,'OK'),(27,1,22,'OK'),(28,1,23,'OK'),(29,1,24,'OK'),(30,2,24,'OK'),(31,2,17,'OK');
/*!40000 ALTER TABLE `moteur_droit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `moteur_historique`
--

DROP TABLE IF EXISTS `moteur_historique`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `moteur_historique` (
  `HISTORIQUE_ID` int(20) NOT NULL auto_increment,
  `HISTORIQUE_DATE` varchar(100) NOT NULL default '',
  `HISTORIQUE_LOGIN` varchar(50) NOT NULL default '',
  `HISTORIQUE_TABLE` varchar(50) NOT NULL default '',
  `HISTORIQUE_TYPE` varchar(10) NOT NULL default '',
  `HISTORIQUE_SQL` text NOT NULL,
  PRIMARY KEY  (`HISTORIQUE_ID`),
  KEY `HISTORIQUE_DATE` (`HISTORIQUE_DATE`),
  KEY `HISTORIQUE_LOGIN` (`HISTORIQUE_LOGIN`),
  KEY `HISTORIQUE_TABLE` (`HISTORIQUE_TABLE`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `moteur_historique`
--

LOCK TABLES `moteur_historique` WRITE;
/*!40000 ALTER TABLE `moteur_historique` DISABLE KEYS */;
/*!40000 ALTER TABLE `moteur_historique` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `moteur_menu`
--

DROP TABLE IF EXISTS `moteur_menu`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `moteur_menu` (
  `MENU_ID` int(20) NOT NULL auto_increment,
  `NOM_MENU` varchar(200) NOT NULL,
  `ORDRE` int(20) NOT NULL,
  `MENU_INFO` text NOT NULL,
  PRIMARY KEY  (`MENU_ID`),
  KEY `NOM_MENU` (`NOM_MENU`),
  KEY `ORDRE` (`ORDRE`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `moteur_menu`
--

LOCK TABLES `moteur_menu` WRITE;
/*!40000 ALTER TABLE `moteur_menu` DISABLE KEYS */;
INSERT INTO `moteur_menu` (`MENU_ID`, `NOM_MENU`, `ORDRE`, `MENU_INFO`) VALUES (1,'Administration',1,'L\\\'outil d\\\'Administration avec :');
/*!40000 ALTER TABLE `moteur_menu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `moteur_pages`
--

DROP TABLE IF EXISTS `moteur_pages`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `moteur_pages` (
  `PAGES_ID` int(20) NOT NULL auto_increment,
  `ITEM` text NOT NULL,
  `URLP` text NOT NULL,
  `LEGEND` text NOT NULL,
  `LEGEND_MENU` text,
  `PAGES_INFO` text NOT NULL,
  `ENABLE` int(1) NOT NULL,
  PRIMARY KEY  (`PAGES_ID`)
) ENGINE=MyISAM AUTO_INCREMENT=25 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `moteur_pages`
--

LOCK TABLES `moteur_pages` WRITE;
/*!40000 ALTER TABLE `moteur_pages` DISABLE KEYS */;
INSERT INTO `moteur_pages` (`PAGES_ID`, `ITEM`, `URLP`, `LEGEND`, `LEGEND_MENU`, `PAGES_INFO`, `ENABLE`) VALUES (1,'','./default.php','Outils','NO MENU - Outils','',0),(2,'login','./login.php','Identification d\'un utilisateur','NO MENU - Identification d\'un utilisateur','',0),(3,'Admin_Gestion_Pages','./Admin/Admin_Gestion_Pages.php','Gestion des Pages','Gestion des Pages','la gestion des pages',0),(4,'Admin_Ajout_Pages','./Admin/Admin_Action_Pages.php','Ajout d\'une Page','NO MENU - Ajout d\'une Page','',0),(5,'Admin_Modif_Gestion_Pages','./Admin/Admin_Modif_Gestion_Pages.php','Gestion des Droits sur une page','NO MENU - Gestion des Droits sur une page','',0),(6,'Admin_Modif_Menu_Pages','./Admin/Admin_Modif_Menu_Pages.php','Gestion des Menus sur une page','NO MENU - Gestion des Menus sur une page','',0),(7,'Admin_Gestion_Utilisateurs','./Admin/Admin_Gestion_Utilisateus.php','Gestion des Utilisateurs','Gestion des Utilisateurs','la gestion des utilisateurs',0),(8,'Admin_Ajout_Utilisateur','./Admin/Admin_Action_Utilisateurs.php','Ajout d\'un Utilisateur','NO MENU - Ajout d\'un Utilisateur','',0),(9,'Admin_Modif_Utilisateur','./Admin/Admin_Action_Utilisateurs.php','Modification d\'un Utilisateur','NO MENU - Modification d\'un Utilisateur','',0),(10,'Admin_Gestion_Menus','./Admin/Admin_Gestion_Menus.php','Gestion des Menus','Gestion des Menus','la gestion des menus',0),(11,'Admin_Ajout_Menu','./Admin/Admin_Action_Menu.php','Ajout d\'un menu','NO MENU - Ajout d\'un menu','',0),(12,'Admin_Modif_Menu','./Admin/Admin_Action_Menu.php','Modification d\'un Menu','NO MENU - Modification d\'un Menu','',0),(13,'vide_admin01','./vide.php','-- Administration --','-- Administration --','NO INFO',0),(14,'Admin_Action_MDP','./Admin/Admin_Action_MDP.php','Gestion du mot de passe','Gestion du mot de passe','la gestion de son mot de passe',0),(15,'Admin_Gestion_Historique','./Admin/Admin_Gestion_Historique.php','Gestion des modifications','Gestion des modifications','la gestion des modifications',0),(16,'Admin_Gestion_Historique_SQL','./Admin/Admin_Gestion_Historique_SQL.php','Information sur une modification','NO MENU - Information sur une modification','Information sur une modification',0),(17,'unlogin','./login.php','Déconnexion','NO MENU - Déconnexion','Déconnexion',0),(18,'Admin_Gestion_Role','./Admin/Admin_Gestion_Role.php','Gestion des Rôles','Gestion des Rôles','la gestion des rôles',0),(19,'Admin_Ajout_Role','./Admin/Admin_Action_Role.php','Ajout d\\\'un rôle','NO MENU - Ajout d\\\'un rôle','Ajout d\\\'un rôle',0),(20,'Admin_Modif_Role','./Admin/Admin_Action_Role.php','Modification d\\\'un rôle','NO MENU - Modification d\\\'un rôle','Modification d\\\'un rôle',0),(21,'historique','./Admin/historique.html','Historique des modifications','Historique des modifications','Historique des modifications',0),(22,'Admin_Gestion_Utilisateurs_info','./Admin/Admin_Gestion_Utilisateurs_info.php','Liste des utilisateurs avec role','NO MENU - Liste des utilisateurs avec role','Liste des utilisateurs avec role',0),(23,'Admin_Gestion_Pages_info','./Admin/Admin_Gestion_Pages_info.php','Liste des pages avec menu et role','NO MENU - Liste des pages avec menu et role','Liste des pages avec menu et role',0),(24,'error','./error.php','Page d\'erreur','NO MENU - Page d\'erreur','Page d\'erreur',0);
/*!40000 ALTER TABLE `moteur_pages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `moteur_role`
--

DROP TABLE IF EXISTS `moteur_role`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `moteur_role` (
  `ROLE_ID` int(20) NOT NULL auto_increment,
  `ROLE` varchar(200) NOT NULL,
  PRIMARY KEY  (`ROLE_ID`),
  KEY `ROLE` (`ROLE`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `moteur_role`
--

LOCK TABLES `moteur_role` WRITE;
/*!40000 ALTER TABLE `moteur_role` DISABLE KEYS */;
INSERT INTO `moteur_role` (`ROLE_ID`, `ROLE`) VALUES (1,'ROOT'),(2,'GUEST');
/*!40000 ALTER TABLE `moteur_role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `moteur_role_utilisateur`
--

DROP TABLE IF EXISTS `moteur_role_utilisateur`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `moteur_role_utilisateur` (
  `ROLE_UTILISATEUR_ID` int(20) NOT NULL auto_increment,
  `ROLE_ID` int(20) NOT NULL,
  `UTILISATEUR_ID` int(20) NOT NULL,
  `ROLE_UTILISATEUR_ACCES` int(1) NOT NULL,
  PRIMARY KEY  (`ROLE_UTILISATEUR_ID`),
  KEY `ROLE_ID` (`ROLE_ID`),
  KEY `UTILISATEUR_ID` (`UTILISATEUR_ID`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `moteur_role_utilisateur`
--

LOCK TABLES `moteur_role_utilisateur` WRITE;
/*!40000 ALTER TABLE `moteur_role_utilisateur` DISABLE KEYS */;
INSERT INTO `moteur_role_utilisateur` (`ROLE_UTILISATEUR_ID`, `ROLE_ID`, `UTILISATEUR_ID`, `ROLE_UTILISATEUR_ACCES`) VALUES (1,1,1,0),(2,2,1,1),(3,2,2,0),(4,1,2,1),(5,2,3,1),(6,1,3,0);
/*!40000 ALTER TABLE `moteur_role_utilisateur` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `moteur_sous_menu`
--

DROP TABLE IF EXISTS `moteur_sous_menu`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `moteur_sous_menu` (
  `SOUS_MENU_ID` int(20) NOT NULL auto_increment,
  `MENU_ID` int(20) NOT NULL,
  `PAGES_ID` int(20) NOT NULL,
  `ORDRE` int(20) NOT NULL,
  PRIMARY KEY  (`SOUS_MENU_ID`),
  KEY `MENU_ID` (`MENU_ID`),
  KEY `PAGES_ID` (`PAGES_ID`),
  KEY `PAGES_ID_2` (`PAGES_ID`),
  KEY `MENU_ID_2` (`MENU_ID`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `moteur_sous_menu`
--

LOCK TABLES `moteur_sous_menu` WRITE;
/*!40000 ALTER TABLE `moteur_sous_menu` DISABLE KEYS */;
INSERT INTO `moteur_sous_menu` (`SOUS_MENU_ID`, `MENU_ID`, `PAGES_ID`, `ORDRE`) VALUES (1,1,3,4),(2,1,7,2),(3,1,10,5),(4,1,13,1),(5,1,14,6),(6,1,15,7),(7,1,18,3),(8,1,21,8);
/*!40000 ALTER TABLE `moteur_sous_menu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `moteur_utilisateur`
--

DROP TABLE IF EXISTS `moteur_utilisateur`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `moteur_utilisateur` (
  `UTILISATEUR_ID` int(20) NOT NULL auto_increment,
  `LOGIN` varchar(200) NOT NULL,
  `NOM` varchar(200) NOT NULL,
  `PRENOM` varchar(200) NOT NULL,
  `EMAIL` varchar(200) NOT NULL,
  `EMAIL_FULL` varchar(200) default NULL,
  `SOCIETE` varchar(50) default NULL,
  `COMPLEMENT` varchar(50) default NULL,
  `MDP_MD5` varchar(200) default NULL,
  `ACCES` enum('L','E') NOT NULL,
  `ENABLE` varchar(1) NOT NULL default 'Y',
  PRIMARY KEY  (`UTILISATEUR_ID`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `moteur_utilisateur`
--

LOCK TABLES `moteur_utilisateur` WRITE;
/*!40000 ALTER TABLE `moteur_utilisateur` DISABLE KEYS */;
INSERT INTO `moteur_utilisateur` (`UTILISATEUR_ID`, `LOGIN`, `NOM`, `PRENOM`, `EMAIL`, `EMAIL_FULL`, `SOCIETE`, `COMPLEMENT`, `MDP_MD5`, `ACCES`, `ENABLE`) VALUES (1,'admin','Admin','Admin','admin','admin','','','21232f297a57a5a743894a0e4a801fc3','E','Y'),(2,'guest','guest','guest','guest','','guest','','084e0343a0486ff05530df6c705c8bb4','E','Y'),(3,'vguibert','Guibert','Vincent','Vincent.Guibert-e','vincent.guibert-e@caissedesdepot.fr','SOGETI','(Sogeti)','de109a75bb8cbe5cb44889bb070e6490','E','Y');
/*!40000 ALTER TABLE `moteur_utilisateur` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2010-09-25 16:58:11
